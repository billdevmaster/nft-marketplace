const SET_WEB3 = 'SET_WEB3';
export const UPDATE_CHAIN_ID = 'UPDATE_CHAIN_ID';
export const UPDATE_USER_ADDRESS = 'UPDATE_USER_ADDRESS';
export const SET_PROFILE = 'SET_PROFILE';
export const UPDATE_PRICE = 'UPDATE_PRICE';
export default SET_WEB3;
