import React, {Suspense} from 'react';

import Landing from './landing';
import Create from './create';
const Publish = () => {
  return (
    <>
      <Landing />
      <Create />
    </>
  );
};
export default Publish;
